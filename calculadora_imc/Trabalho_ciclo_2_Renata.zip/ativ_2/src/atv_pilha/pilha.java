package atv_pilha;

import java.util.Scanner;
import java.util.Stack;
 
class pilha
{
    
	// Fun��o que inverte uma string usando pilha
    public static String reverse(String str)
    {
        // Verificando se a string � vazia ou nula
        if (str == null || str.equals(""))
            return str;
 
        // Criando uma pilha de caracter vazia
        Stack<Character> stack = new Stack<Character>();
        
        // Movendo os caracteres para a pilha
        char[] ch = str.toCharArray();
        for (int i = 0; i < str.length(); i++)
            stack.push(ch[i]);
 
        // iniciando index com 0
        int k = 0;
 
        // Retirando caracteres da pilha, at� que esteja vazia
        while (!stack.isEmpty())
        {
            // Apontando cada caracter retirado de volta para o array
            ch[k++] = stack.pop();
        }
 
        // Convertendo array para string
        return String.copyValueOf(ch);
    }
 
    public static void main (String[] args)
    {   
    	Scanner input = new Scanner(System.in);
    	System.out.print("Digite a palavra: ");
    	 String str = input.next();
        
    	 
    	 
        str = reverse(str);        
        System.out.print("A String invertida �: " + str);
        ;
    }
}