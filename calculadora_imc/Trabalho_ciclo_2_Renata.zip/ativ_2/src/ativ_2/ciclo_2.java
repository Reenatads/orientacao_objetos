package ativ_2;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class ciclo_2 {

	public static void main(String[] args) {

	    Queue<String> ordemChegada = new LinkedList<String>();
	    /*ordemChegada.add("");*/
	   
	    
	    
	    Scanner input = new Scanner(System.in);

	    boolean done = false;
	    while(done == false) 
	    {

	        System.out.println("");
	        System.out.println("##### MENU - Atendimento #####"); 
	        System.out.println("1. Inserir paciente: ");
	        System.out.println("2. Remover paciente da fila de espera: ");
	        System.out.println("3. Consultar se paciente existe na fila: ");
	        System.out.println("4. Consultar lista completa: ");
	        System.out.println("5. Sair");
	        System.out.println("");

	        int selection=input.nextInt();
	        
	         
	        switch(selection) 
	        {

	        case 1://Inserindo paciente
	            System.out.println("Escreva o primeiro nome do paciente: ");
	            String insertData = input.next();
	            ordemChegada.add(insertData);
	            break;
	            
	        case 2://Excluindo paciente da lista de espera
	            System.out.print("Paciente removido da fila :");
	            String aux = ordemChegada.peek();
	            System.out.println(aux);
	            ordemChegada.poll();
	            System.out.print("Fila atualizada: ");
	            System.out.println(ordemChegada);
	            break;
	            
	        case 3: //Procurando elemento
	        	 
	        	System.out.print("Digite o nome do paciente que deseja pesquisar: ");
	        	String buscaTarefa = input.next();
	        	if (ordemChegada.contains(buscaTarefa) == true)
	        	System.out.println("O paciente existe na Fila");
	        	else if (ordemChegada.contains(buscaTarefa) == false)
	        	System.out.println("O paciente n�o existe na Fila");
	        	break;
	      
	        case 4: //consultar lista completa:
	        	System.out.print("Exibindo lista completa: ");
	            System.out.println(ordemChegada);
	            break;
	            
	        case 5: //sair
	        	System.out.println("Finalizando programa...");
	            done = true;
	            break;
	        }   
	    }
	  }
	}

